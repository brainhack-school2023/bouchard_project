#!/bin/bash
#SBATCH --account=def-jcohen #TODO: add your account
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=2
#SBATCH --mem-per-cpu=1000M
#SBATCH --time=5:00
#####
# TODO: Add the right option for the array job
#SBATCH --array=0-8:1
#####
#SBATCH --job-name=ex4
#SBATCH --output ex4.out

module load gcc boost

SRCDIR=../photos/

# List of available filters
FILTERS=(grayscale edges emboss negate solarize flip flop monochrome add_noise)

#####
# TODO: Use the FILTERS list to select the right filter according to the value
# of SLURM_ARRAY_TASK_ID
FILTERS=('grayscale', 'edges', 'emboss', 'negate', 'solarize','flip', 'flop', 'monochrome', 'add_noise')
#####
parallel ../filterImage.exe --srcdir $SRCDIR --files {1} --filters ${FILTERS[$SLURM_ARRAY_TASK_ID]} ::: $(ls $SRCDIR)
