#!/bin/bash

#SBATCH --account=def-jcohen --output ex1.out --nodes 1 --time=0:02:00 --cpus-per-task 1


echo "Bonjour"
