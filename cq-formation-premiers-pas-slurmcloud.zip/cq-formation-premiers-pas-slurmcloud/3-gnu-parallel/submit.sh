#!/bin/bash
#SBATCH --account=def-jcohen #TODO: add your account
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#####
# TODO: Add the option --cpus-per-task
#SBATCH --cpus-per-task 2
#####
#SBATCH --mem-per-cpu=1000M
#SBATCH --time=5:00
#SBATCH --job-name=ex3
#SBATCH --output ex3.out

module load gcc boost

SRCDIR=../photos/

parallel echo {1} ::: $(ls ../photos)

#####
# TODO: Add the parrallel command with the right files and arguments
#####
parallel ../filterImage.exe --srcdir $SRCDIR --files {1} --filters grayscale ::: $(ls ../photos)
