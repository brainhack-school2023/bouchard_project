#!/bin/bash
#SBATCH --account=def-jcohen #TODO: add your account
#####
# TODO: Change the configuration to use 2 nodes, 2 tasks per node et 1 CPU per task
#####
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=2
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=1000M
#SBATCH --time=5:00
#SBATCH --job-name=ex5

module load gcc boost

SRCDIR=../photos/
FILTERS="grayscale edges emboss negate solarize flip flop monochrome add_noise"

####
# TODO: Run the executable ../filterImage.exe with mpiexec
####
mpiexec ../filterImage.exe --srcdir $SRCDIR --files $(ls $SRCDIR) --filters $FILTERS
